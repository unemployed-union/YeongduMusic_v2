const assert = require('node:assert/strict');
const { loadSource } = require('./test-source-loader.cjs');
const jsx = (type, props) => ({ type, props });
const content = jsx('ExistingSettingsStack', {});
let loads = 0;
function binding(nativeModule) {
  return loadSource('src/features/settings/settings-sheet-background.ios.tsx', {
    '@/theme/tokens': { useAppColorScheme: () => 'dark' },
    '@expo/ui/swift-ui/modifiers': { createModifier: ($type) => ({ $type }) },
    'react/jsx-runtime': { jsx, jsxs: jsx },
    'react-native': { View: 'View', StyleSheet: { create: (value) => value } },
    expo: {
      requireOptionalNativeModule: () => nativeModule,
      requireNativeView: () => {
        loads++;
        return 'NativeBackgroundAnchor';
      },
    },
  });
}
for (const nativeModule of [null, { isSupported: false }, { isSupported: true }]) {
  const fallback = binding(nativeModule);
  assert.equal(fallback.usesNativeSettingsSheetBackground, false);
  assert.equal(fallback.SettingsSheetBackground({ children: content }), content);
}
assert.equal(loads, 0, 'Older OS / old binaries / Expo Go do not require the native view');
const supported = binding({ isSupported: true, supportsThresholdSurfaces: true });
const tree = supported.SettingsSheetBackground({ children: content });
assert.equal(supported.usesNativeSettingsSheetBackground, true);
assert.equal(supported.settingsGroupBackgroundModifier.$type, 'yeongduSettingsGroupBackground');
assert.equal(tree.props.children[0], content, 'Keep the native stack and its scroll hierarchy first');
const anchor = tree.props.children[1];
assert.equal(anchor.type, 'NativeBackgroundAnchor');
assert.equal(anchor.props.pointerEvents, 'none');
assert.equal(anchor.props.accessible, false);
assert.equal(anchor.props.colorScheme, 'dark', 'Native backdrop follows the existing app theme');
assert.equal(tree.props.style.opacity, undefined, 'Content is not faded');
assert.equal(tree.props.style.backgroundColor, undefined, 'No whole-screen painted layer');
const baseline = binding({ isSupported: true, supportsThresholdSurfaces: true, isEnabled: false });
assert.equal(baseline.usesNativeSettingsSheetBackground, false, 'QA baseline retains the default List background');
assert.equal(baseline.settingsGroupBackgroundModifier, null);
const other = loadSource('src/features/settings/settings-sheet-background.tsx');
assert.equal(other.usesNativeSettingsSheetBackground, false);
assert.equal(other.SettingsSheetBackground({ children: content }), content);
console.log('PASS: native capability fallback, Android passthrough, retained content/scroll order, noninteractive anchor and no content opacity. UIKit interpolation/drag is not mocked by this check.');
