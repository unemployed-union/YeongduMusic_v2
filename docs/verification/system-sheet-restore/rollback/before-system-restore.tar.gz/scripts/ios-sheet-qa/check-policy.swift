import Foundation

@main struct CheckSheetPolicy {
  static func main() {
    var opaque = false
    let samples: [(CGFloat, Bool)] = [
      (0.5, false), (0.84, false), (0.85, true), (0.83, true),
      (0.79, true), (0.78, true), (0.779, false), (0.84, false),
      (0.86, true), (0.77, false)
    ]
    for (ratio, expected) in samples {
      opaque = SheetAppearancePolicy.wantsOpaque(current: opaque, heightRatio: ratio, reduceTransparency: false)
      precondition(opaque == expected, "Incorrect hysteresis at \(ratio)")
    }
    precondition(SheetAppearancePolicy.wantsOpaque(current: false, heightRatio: 0.5, reduceTransparency: true))
    precondition(SheetAppearancePolicy.wantsOpaque(current: true, heightRatio: .nan, reduceTransparency: false))
    precondition(!SheetAppearancePolicy.wantsOpaque(current: false, heightRatio: .nan, reduceTransparency: false))
    precondition((0.18...0.22).contains(SheetAppearancePolicy.animationDuration))
    print("PASS: maximum-height ratios, both thresholds, hysteresis band, fast reversals, invalid geometry and Reduce Transparency policy; UIKit rendering/animation not mocked.")
  }
}
