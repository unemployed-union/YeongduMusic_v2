Pod::Spec.new do |s|
  s.name = 'YeongduSheetBackground'
  s.version = '1.0.0'
  s.summary = 'Native settings sheet background effects'
  s.description = s.summary
  s.license = 'MIT'
  s.author = 'Yeongdu'
  s.homepage = 'https://developer.apple.com/documentation/uikit/uisheetpresentationcontroller'
  s.source = { :git => 'https://github.com/expo/expo.git' }
  s.platforms = { :ios => '16.4' }
  s.swift_version = '5.9'
  s.static_framework = true
  s.dependency 'ExpoModulesCore'
  s.dependency 'ExpoUI'
  s.source_files = '**/*.swift'
  s.frameworks = 'UIKit'
end
