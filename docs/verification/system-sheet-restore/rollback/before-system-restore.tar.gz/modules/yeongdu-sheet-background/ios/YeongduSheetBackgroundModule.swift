import ExpoModulesCore
import UIKit
import QuartzCore
import ExpoUI

public class YeongduSheetBackgroundModule: Module {
  public func definition() -> ModuleDefinition {
    Name("YeongduSheetBackground")
    Constant("supportsThresholdSurfaces") { true }

    OnCreate {
      ViewModifierRegistry.register("yeongduSettingsGroupBackground") { _, _, _ in
        SettingsGroupBackgroundModifier()
      }
    }
    OnDestroy {
      ViewModifierRegistry.unregister("yeongduSettingsGroupBackground")
    }

    Constant("isSupported") {
      if #available(iOS 26.1, *) {
        return true
      }
      return false
    }

    Constant("isEnabled") {
      #if targetEnvironment(simulator)
      // Process-only baseline for XCTest; never changes preferences or device builds.
      if ProcessInfo.processInfo.environment["YEONGDU_SHEET_QA_BASELINE"] == "1" {
        return false
      }
      #endif
      return true
    }

    View(SettingsSheetBackgroundView.self) {
      Prop("colorScheme") { (view: SettingsSheetBackgroundView, scheme: String) in
        view.setColorScheme(scheme)
      }
    }
  }
}

/// Attaches a background-only driver to the existing UIKit sheet; never owns gestures.
final class SettingsSheetBackgroundView: ExpoView {
  private weak var configuredSheet: UISheetPresentationController?
  private var configuredDetents: [UISheetPresentationController.Detent] = []
  private var originalDetents: [UISheetPresentationController.Detent] = []
  private var originalSheetEffect: UIVisualEffect?
  private var originalSheetTraits: UITraitCollection?
  private var installedSheetTraits: UITraitCollection?
  private var installedSheetEffect: UIVisualEffect?
  private var motion: SheetBackgroundMotion?
  private var colorScheme: UIUserInterfaceStyle = .unspecified
  private var configuredReducedTransparency = false
  private var pendingAttachment = false
  #if targetEnvironment(simulator)
  private let qa = SheetBackgroundQA()
  #endif

  required init(appContext: AppContext? = nil) {
    super.init(appContext: appContext)
    backgroundColor = .clear
    isUserInteractionEnabled = false
    isAccessibilityElement = false
    NotificationCenter.default.addObserver(
      self,
      selector: #selector(accessibilityChanged),
      name: UIAccessibility.reduceTransparencyStatusDidChangeNotification,
      object: nil
    )
  }

  deinit {
    NotificationCenter.default.removeObserver(self)
  }

  override func didMoveToWindow() {
    super.didMoveToWindow()
    if window == nil {
      restoreEffects()
      return
    }
    configureIfReady()
    scheduleAttachment()
  }

  override func layoutSubviews() {
    super.layoutSubviews()
    configureIfReady()
  }

  /// One deferred attachment handles the native presentation's initial mounting order.
  private func scheduleAttachment() {
    guard !pendingAttachment else {
      return
    }
    pendingAttachment = true
    DispatchQueue.main.async { [weak self] in
      guard let self else {
        return
      }
      self.pendingAttachment = false
      self.configureIfReady()
    }
  }

  @objc private func accessibilityChanged() {
    configureIfReady()
  }

  func setColorScheme(_ scheme: String) {
    colorScheme = scheme == "dark" ? .dark : .light
    motion?.setColorScheme(colorScheme)
    if #available(iOS 26.1, *), let sheet = configuredSheet {
      applyMaterial(to: sheet)
    }
  }

  @available(iOS 26.1, *)
  private func applyMaterial(to sheet: UISheetPresentationController) {
    let traits = UITraitCollection(traitsFrom: [
      originalSheetTraits ?? UITraitCollection(),
      UITraitCollection(userInterfaceStyle: colorScheme)
    ])
    installedSheetTraits = traits
    sheet.overrideTraitCollection = traits
    // Suppress UIKit's independent detent material switching. The visible native
    // Glass view lives behind this controller's content and keeps alpha == 1.
    let effect = UIVisualEffect()
    installedSheetEffect = effect
    for detent in configuredDetents {
      detent.backgroundEffect = effect
    }
    sheet.backgroundEffect = effect
  }

  private func configureIfReady() {
    guard #available(iOS 26.1, *), window != nil,
      let sheet = enclosingSettingsSheet(from: next), sheet.detents.count == 2 else {
      return
    }
    let detents = sheet.detents
    #if targetEnvironment(simulator)
    if SheetBackgroundQA.isBaseline {
      qa.attach(to: sheet)
      return
    }
    #endif
    // Some early OS builds omit setters present in the SDK; retain their system default.
    let setter = #selector(setter: UISheetPresentationController.Detent.backgroundEffect)
    guard detents.allSatisfy({ $0.responds(to: setter) }) else {
      return
    }
    let reducedTransparency = UIAccessibility.isReduceTransparencyEnabled
    let sameDetents = configuredSheet === sheet &&
      configuredDetents.count == detents.count &&
      zip(configuredDetents, detents).allSatisfy { pair in pair.0 === pair.1 }
    if sameDetents && configuredReducedTransparency == reducedTransparency {
      return
    }
    if !sameDetents {
      restoreEffects()
      configuredSheet = sheet
      configuredDetents = detents
      originalDetents = detents
      originalSheetEffect = sheet.backgroundEffect
      originalSheetTraits = sheet.overrideTraitCollection
    }
    #if targetEnvironment(simulator)
    qa.attach(to: sheet)
    #endif
    configuredReducedTransparency = reducedTransparency

    if !sameDetents {
      let driver = SheetBackgroundMotion(sheet: sheet)
      motion = driver
      driver.setColorScheme(colorScheme)
      // Preserve each resolver and identifier. UIKit still owns detents and all gestures.
      configuredDetents = originalDetents.enumerated().map { index, original in
        let detent = UISheetPresentationController.Detent.custom(identifier: original.identifier) { [weak driver] context in
          let height = original.resolvedValue(in: context)
          driver?.resolvedHeights[index] = height
          return height
        }
        return detent
      }
      applyMaterial(to: sheet)
      sheet.detents = configuredDetents
      driver.start()
    }
  }

  private func restoreEffects() {
    #if targetEnvironment(simulator)
    qa.reset()
    #endif
    if #available(iOS 26.1, *), let sheet = configuredSheet {
      let ownsCurrentDetents = sheet.detents.count == configuredDetents.count &&
        zip(sheet.detents, configuredDetents).allSatisfy { pair in pair.0 === pair.1 }
      // Do not alter a replacement controller or interrupt the system's dismiss animation.
      if !sheet.presentedViewController.isBeingDismissed {
        if sheet.backgroundEffect === installedSheetEffect {
          sheet.backgroundEffect = originalSheetEffect
        }
        if sheet.overrideTraitCollection == installedSheetTraits {
          sheet.overrideTraitCollection = originalSheetTraits
        }
        if ownsCurrentDetents {
          sheet.detents = originalDetents
        }
      }
    }
    motion?.stop()
    motion = nil
    configuredSheet = nil
    configuredDetents = []
    originalDetents = []
    originalSheetEffect = nil
    originalSheetTraits = nil
    installedSheetTraits = nil
    installedSheetEffect = nil
  }
}

/// Reads the public presentation-layer geometry on the main/UI thread, including
/// UIKit's post-release spring. No JS frame events, scroll offsets or detent-arrival fade.
private final class SheetBackgroundMotion {
  weak var sheet: UISheetPresentationController?
  var resolvedHeights: [Int: CGFloat] = [:]
  private let backdrop = SettingsSheetGlassBackdrop()
  private var surface: UIView { backdrop.opaqueSurface }
  private var displayLink: CADisplayLink?
  private let target = SheetDisplayLinkTarget()
  private var geometrySize: CGSize?
  private var geometryInset: CGFloat?
  private let surfaces: SettingsSheetSurfaces
  #if targetEnvironment(simulator)
  private var lastLoggedProgress: Int = -1
  #endif

  init(sheet: UISheetPresentationController) {
    self.sheet = sheet
    surfaces = SettingsSheetSurfaces.forSheet(sheet)
    surface.backgroundColor = .systemGroupedBackground
    surface.isUserInteractionEnabled = false
    surface.isAccessibilityElement = false
    surface.alpha = 0
    target.owner = self
  }

  func setColorScheme(_ scheme: UIUserInterfaceStyle) {
    backdrop.overrideUserInterfaceStyle = scheme
  }

  func start() {
    guard let view = sheet?.presentedViewController.view else {
      return
    }
    backdrop.frame = view.bounds
    backdrop.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    view.insertSubview(backdrop, at: 0)
    surfaces.register(surface)
    if UIAccessibility.isReduceTransparencyEnabled {
      surfaces.setOpaque(true, animated: false)
    }
    let link = CADisplayLink(target: target, selector: #selector(SheetDisplayLinkTarget.tick))
    link.add(to: .main, forMode: .common)
    displayLink = link
    update()
  }

  func stop() {
    displayLink?.invalidate()
    displayLink = nil
    surfaces.unregister(surface)
    backdrop.removeFromSuperview()
  }

  deinit {
    displayLink?.invalidate()
  }

  func update() {
    guard let sheet, let view = sheet.presentedView, let container = sheet.containerView,
      let lower = resolvedHeights[0], let upper = resolvedHeights[1],
      lower.isFinite, upper.isFinite, upper > lower else {
      return
    }
    // Capture safe-area attachment geometry once, not at a selected-detent event.
    // UIKit's model bounds can still be the full size during initial presentation;
    // waiting for them to equal the lower detent would miss the first drag.
    if geometrySize != container.bounds.size {
      geometryInset = nil
      geometrySize = container.bounds.size
    }
    guard !sheet.presentedViewController.isBeingPresented else {
      return
    }
    if geometryInset == nil {
      let windowInset = view.window?.safeAreaInsets.bottom ?? 0
      let frame = view.layer.convert(view.layer.bounds, to: container.layer)
      let bottomGap = container.bounds.maxY - frame.maxY
      let edgeAttached = bottomGap >= -1 && bottomGap <= windowInset + 1
      geometryInset = edgeAttached ? windowInset : view.safeAreaInsets.bottom
    }
    guard let inset = geometryInset else {
      return
    }
    #if targetEnvironment(simulator)
    surfaces.probeReversalIfRequested(on: surface)
    if surfaces.probingReversal {
      return
    }
    #endif
    backdrop.prepareVisibleMaterial()
    let layer = view.layer.presentation() ?? view.layer
    let height = layer.bounds.height
    let ratio = (height - inset) / upper
    let reduceTransparency = UIAccessibility.isReduceTransparencyEnabled
    let opaque = SheetAppearancePolicy.wantsOpaque(
      current: surfaces.isOpaque, heightRatio: ratio, reduceTransparency: reduceTransparency
    )
    let animated = !UIAccessibility.isReduceMotionEnabled && !reduceTransparency
    surfaces.setOpaque(opaque, animated: animated)
    #if targetEnvironment(simulator)
    if ProcessInfo.processInfo.environment["YEONGDU_SHEET_QA_CONTRAST"] == "1" {
      let step = Int(ratio * 100)
      if step != lastLoggedProgress {
        lastLoggedProgress = step
        NSLog("[SheetHeightQA] ratio=%.4f opaque=%@ alpha=%.4f", ratio,
              surfaces.isOpaque ? "true" : "false",
              surface.layer.presentation()?.opacity ?? Float(surface.alpha))
      }
    }
    #endif
  }
}

private final class SheetDisplayLinkTarget: NSObject {
  weak var owner: SheetBackgroundMotion?

  @objc func tick() {
    owner?.update()
  }
}

#if targetEnvironment(simulator)
/// Optical contrast fixture for XCTest recordings, behind the real app's sheet.
/// No fixture code is compiled into iPhone/iPad device builds.
private final class SheetBackgroundQA {
  static var isBaseline: Bool {
    ProcessInfo.processInfo.environment["YEONGDU_SHEET_QA_BASELINE"] == "1"
  }
  private var backdrop: UIView?

  func attach(to sheet: UISheetPresentationController) {
    guard ProcessInfo.processInfo.environment["YEONGDU_SHEET_QA_CONTRAST"] == "1",
      let presenter = sheet.presentingViewController.view else {
      return
    }
    if backdrop?.superview === presenter {
      return
    }
    reset()
    let view = ContrastBackdrop(frame: presenter.bounds)
    view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    view.isUserInteractionEnabled = false
    view.isAccessibilityElement = false
    presenter.addSubview(view)
    backdrop = view
  }

  func reset() {
    backdrop?.removeFromSuperview()
    backdrop = nil
  }
}

private final class ContrastBackdrop: UIView {
  override func draw(_ rect: CGRect) {
    let colors: [UIColor] = [.systemRed, .systemBlue, .systemTeal, .systemYellow]
    for (index, color) in colors.enumerated() {
      color.setFill()
      UIRectFill(CGRect(x: bounds.width * CGFloat(index) / 4, y: 0,
                        width: bounds.width / 4, height: bounds.height))
    }
  }
}
#endif
