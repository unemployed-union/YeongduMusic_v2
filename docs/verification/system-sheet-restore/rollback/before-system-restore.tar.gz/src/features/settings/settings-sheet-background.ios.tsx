import { requireNativeView, requireOptionalNativeModule } from 'expo';
import { createModifier } from '@expo/ui/swift-ui/modifiers';
import { useAppColorScheme } from '@/theme/tokens';
import type { ReactNode } from 'react';
import { StyleSheet, View, type ViewProps } from 'react-native';

const nativeModule = requireOptionalNativeModule<{
  isSupported: boolean;
  isEnabled?: boolean;
  supportsThresholdSurfaces?: boolean;
}>(
  'YeongduSheetBackground',
);

const supportsThresholdSurfaces = nativeModule?.isSupported === true &&
  nativeModule.supportsThresholdSurfaces === true;

export const usesNativeSettingsSheetBackground =
  supportsThresholdSurfaces && nativeModule?.isEnabled !== false;

export const settingsGroupBackgroundModifier = usesNativeSettingsSheetBackground
  ? createModifier('yeongduSettingsGroupBackground')
  : null;

const NativeBackground = supportsThresholdSurfaces
  ? requireNativeView<ViewProps & { colorScheme: 'dark' | 'light' }>('YeongduSheetBackground')
  : null;

export function SettingsSheetBackground({ children }: { children: ReactNode }) {
  const scheme = useAppColorScheme();
  if (!NativeBackground) {
    return children;
  }
  return (
    <View style={styles.container}>
      {children}
      <NativeBackground style={styles.anchor} colorScheme={scheme} pointerEvents="none" accessible={false} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  anchor: { position: 'absolute', width: 1, height: 1 },
});
