import type { ReactNode } from 'react';

export const usesNativeSettingsSheetBackground = false;
export const settingsGroupBackgroundModifier = null;

export function SettingsSheetBackground({ children }: { children: ReactNode }) {
  return children;
}
