import { SettingsNavigator } from '@/features/settings/settings-navigator';
import { SettingsSheetBackground } from '@/features/settings/settings-sheet-background';

export const unstable_settings = { anchor: 'settings/index' };

export default function SettingsLayout() {
  return (
    <SettingsSheetBackground>
      <SettingsNavigator />
    </SettingsSheetBackground>
  );
}
