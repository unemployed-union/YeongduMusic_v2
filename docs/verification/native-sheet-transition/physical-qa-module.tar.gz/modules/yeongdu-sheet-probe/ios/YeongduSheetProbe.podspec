Pod::Spec.new do |s|
  s.name = 'YeongduSheetProbe'
  s.version = '1.0.0'
  s.summary = 'Temporary process-enabled native sheet diagnostic'
  s.license = 'MIT'
  s.author = 'Yeongdu'
  s.homepage = 'https://developer.apple.com/documentation/uikit/uisheetpresentationcontroller'
  s.source = { :git => 'https://github.com/expo/expo.git' }
  s.platforms = { :ios => '16.4' }
  s.swift_version = '5.9'
  s.static_framework = true
  s.dependency 'ExpoModulesCore'
  s.source_files = '**/*.swift'
  s.frameworks = 'UIKit', 'SwiftUI'
end
