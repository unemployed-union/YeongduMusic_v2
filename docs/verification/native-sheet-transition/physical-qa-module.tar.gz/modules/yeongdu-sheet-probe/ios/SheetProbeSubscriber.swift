import ExpoModulesCore
import UIKit

/// Diagnostic only. It never changes the real settings sheet or any effect.
public final class SheetProbeSubscriber: ExpoAppDelegateSubscriber {
  public func application(_ application: UIApplication,
                          didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
    guard ProcessInfo.processInfo.environment["YEONGDU_NATIVE_SHEET_PROBE"] == "1" else {
      return true
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
      guard let window = UIApplication.shared.connectedScenes
        .compactMap({ $0 as? UIWindowScene })
        .flatMap({ $0.windows }).first(where: { $0.isKeyWindow }),
        var presenter = window.rootViewController else {
        return
      }
      while let presented = presenter.presentedViewController {
        presenter = presented
      }
      let probe = ProbePresenter()
      probe.modalPresentationStyle = .fullScreen
      let originalPresenter = presenter
      probe.openRealSettings = { [weak probe, weak originalPresenter] in
        probe?.dismiss(animated: true) {
          guard let originalPresenter else {
            return
          }
          let backdrop = DiagnosticUnderlay(frame: originalPresenter.view.bounds)
          backdrop.autoresizingMask = [.flexibleWidth, .flexibleHeight]
          originalPresenter.view.addSubview(backdrop)
          // Deliver through the app's public linking delegate, avoiding another
          // installed app that may register the same URL scheme.
          _ = UIApplication.shared.delegate?.application?(
            UIApplication.shared, open: URL(string: "synologymusic:///settings")!, options: [:])
        }
      }
      presenter.present(probe, animated: true)
      let report: [String: Any] = [
        "os": ProcessInfo.processInfo.operatingSystemVersionString,
        "sdk": Bundle.main.object(forInfoDictionaryKey: "DTSDKName") as? String ?? "unknown",
        "animationsEnabled": UIView.areAnimationsEnabled,
        "windowLayerSpeed": window.layer.speed,
        "presenterLayerSpeed": presenter.view.layer.speed,
        "darkerSystemColors": UIAccessibility.isDarkerSystemColorsEnabled,
        "reduceMotion": UIAccessibility.isReduceMotionEnabled,
        "reduceTransparency": UIAccessibility.isReduceTransparencyEnabled,
        "prefersCrossFadeTransitions": UIAccessibility.prefersCrossFadeTransitions
      ]
      do {
        let data = try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        try data.write(to: directory.appendingPathComponent("native-sheet-probe.json"))
      } catch {
        NSLog("Native sheet diagnostic metadata could not be written: %@", error.localizedDescription)
      }
    }
    return true
  }
}

/// Test content behind the sheet, never a replacement for its material.
private final class DiagnosticUnderlay: UIView {
  private let close = UIButton(type: .system)

  override init(frame: CGRect) {
    super.init(frame: frame)
    close.setTitle("비교 배경 닫기", for: .normal)
    close.addAction(UIAction { [weak self] _ in
      self?.removeFromSuperview()
    }, for: .touchUpInside)
    addSubview(close)
  }

  required init?(coder: NSCoder) {
    fatalError("Storyboard initialization is not used")
  }

  override func layoutSubviews() {
    super.layoutSubviews()
    close.frame = CGRect(x: 20, y: safeAreaInsets.top + 12, width: bounds.width - 40, height: 48)
  }

  override func draw(_ rect: CGRect) {
    for (index, color) in [UIColor.systemRed, .systemBlue, .systemTeal, .systemYellow].enumerated() {
      color.setFill()
      UIRectFill(CGRect(x: bounds.width * CGFloat(index) / 4, y: 0,
                       width: bounds.width / 4, height: bounds.height))
    }
  }
}
